<?php 

class Message {
    private $user_obj;
    private $con;

    public function __construct($con, $user) {
        $this->con = $con;
        $this->user_obj = new User($con, $user);
    }

    public function getMostRecentUser() {
        $userLoggedIn = $this->user_obj->getUsername();
        $stmt = $this->con->prepare("SELECT user_to, user_from FROM messages WHERE user_to=? OR user_from=? ORDER BY id DESC LIMIT 1");
        $stmt->bind_param("ss", $userLoggedIn, $userLoggedIn);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            return false;
        }

        $row = $result->fetch_assoc();
        $stmt->close();

        $user_to = $row['user_to'];
        $user_from = $row['user_from'];

        return $user_to != $userLoggedIn ? $user_to : $user_from;
    }

    public function getLastMsg($userLoggedIn, $otheruser) {
        $info_array = array();
        $stmt = $this->con->prepare("SELECT body, user_to, date FROM messages WHERE (user_to=? AND user_from=?) OR (user_from=? AND user_to=?) ORDER BY id DESC LIMIT 1");
        $stmt->bind_param("ssss", $userLoggedIn, $otheruser, $userLoggedIn, $otheruser);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            return ["", "", ""];  // Return empty array if no message is found
        }

        $row = $result->fetch_assoc();
        $stmt->close();

        $sent_by = ($row['user_to'] == $userLoggedIn) ? "They said: " : "You said: ";

        $date_time_now = date("Y-m-d H:i:s");
        $start_date = new DateTime($row['date']);
        $end_date = new DateTime($date_time_now);
        $interval = $start_date->diff($end_date);

        if ($interval->y >= 1) {
            $time_message = $interval->y == 1 ? "1 year ago" : $interval->y . " years ago";
        } elseif ($interval->m >= 1) {
            $days = $interval->d == 0 ? " ago" : ($interval->d == 1 ? "1 day ago" : $interval->d . " days ago");
            $time_message = $interval->m == 1 ? "1 month" . $days : $interval->m . " months" . $days;
        } elseif ($interval->d >= 1) {
            $time_message = $interval->d == 1 ? "Yesterday" : $interval->d . " days ago";
        } elseif ($interval->h >= 1) {
            $time_message = $interval->h == 1 ? "1 hour ago" : $interval->h . " hours ago";
        } elseif ($interval->i >= 1) {
            $time_message = $interval->i == 1 ? "1 minute ago" : $interval->i . " minutes ago";
        } else {
            $time_message = $interval->s < 30 ? "Just now" : $interval->s . " seconds ago";
        }

        array_push($info_array, $sent_by, $row['body'], $time_message);

        return $info_array;
    }

    public function sendMessage($user_to, $body, $date) {
        if ($body != "") {
            $userLoggedIn = $this->user_obj->getUsername();
            $stmt = $this->con->prepare("INSERT INTO messages VALUES('', ?, ?, ?, ?, 'no', 'no', 'no')");
            $stmt->bind_param("ssss", $user_to, $userLoggedIn, $body, $date);
            $stmt->execute();
            $stmt->close();
        }
    }

    public function getMessages($otheruser) {
        $userLoggedIn = $this->user_obj->getUsername();
        $data = "";

        $stmt = $this->con->prepare("UPDATE messages SET opened='yes' WHERE user_to=? AND user_from=?");
        $stmt->bind_param("ss", $userLoggedIn, $otheruser);
        $stmt->execute();
        $stmt->close();

        $stmt = $this->con->prepare("SELECT * FROM messages WHERE (user_to=? AND user_from=?) OR (user_from=? AND user_to=?)");
        $stmt->bind_param("ssss", $userLoggedIn, $otheruser, $userLoggedIn, $otheruser);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $user_to = $row['user_to'];
            $body = $row['body'];
            $div_top = ($user_to == $userLoggedIn) ? "<div class='msg' id='green'>" : "<div class='msg' id='blue'>";
            $data .= $div_top . $body . "</div><br><br>";
        }
        $stmt->close();

        return $data;
    }

    public function getOtherChats() {
        $userLoggedIn = $this->user_obj->getUsername();
        $return_string = "";
        $chat = array();

        $stmt = $this->con->prepare("SELECT user_to, user_from FROM messages WHERE user_to=? OR user_from=?");
        $stmt->bind_param("ss", $userLoggedIn, $userLoggedIn);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $user_to_push = ($row['user_to'] != $userLoggedIn) ? $row['user_to'] : $row['user_from'];
            if (!in_array($user_to_push, $chat)) {
                array_push($chat, $user_to_push);
            }
        }
        $stmt->close();

        foreach ($chat as $username) {
            $user_found_obj = new User($this->con, $username);
            $last_msg_detail = $this->getLastMsg($userLoggedIn, $username);
            $dots = (strlen($last_msg_detail[1]) >= 12) ? "..." : "";
            $split = str_split($last_msg_detail[1], 12);
            $split = $split[0] . $dots;

            $return_string .= "<a href='messages.php?u=$username'>
                                  <div class='user_found_msg'>
                                      <div class='img'>
                                          <img src='" . $user_found_obj->getProfilePic() . "' style='margin-right: 7px; height:50px; width: 50px; border-radius: 7px;'>
                                      </div>
                                      <div class='chat_name'>
                                          " . $user_found_obj->getFnameAndLname() . "
                                      </div>
                                      <div class='other'>
                                          <span class='time_sml' id='grey'>" . $last_msg_detail[2] . "</span>
                                          <p class='chat_p'>" . $last_msg_detail[0] . $split . "</p>
                                      </div>
                                  </div>
                               </a><hr>";
        }

        return $return_string;
    }

    public function getUnreadNumber() {
        $userLoggedIn = $this->user_obj->getUsername();
        $stmt = $this->con->prepare("SELECT * FROM messages WHERE opened='no' AND user_to=?");
        $stmt->bind_param("s", $userLoggedIn);
        $stmt->execute();
        $result = $stmt->get_result();
        $num_unread = $result->num_rows;
        $stmt->close();

        return $num_unread;
    }
}

?>
